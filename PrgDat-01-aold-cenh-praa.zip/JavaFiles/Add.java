import java.util.HashMap;

public class Add extends Binop {
    Expr e1;
    Expr e2;

    public Add(Expr e1, Expr e2) {
        this.e1 = e1;
        this.e2 = e2;
    }

    @Override
    public String toString() {
        return "(" + e1.toString() + " + " + e2.toString() + ")"; 
    }

    @Override
    public int eval(HashMap<String, Integer> env) {
        return e1.eval(env) + e2.eval(env);
    }

    @Override
    public Expr simplify() {
            if (e1.equals(new Csti(0))){
                return e2.simplify();
            }
            else if (e2.equals(new Csti(0))){
                return e1.simplify();
            }
        return new Add(e1.simplify(), e2.simplify());
    }
}
